dotValues = [];

function preload() {
  table = loadTable("horsepower.csv", "csv", "header");
}

function setup() {
  createCanvas(700, 400);
  numRows = table.getRowCount();
  numColumns = table.getColumnCount();
}

function draw() {
  background(240);
  fill("steelblue");
  stnum = 50;
  for (var i = 0; i < 10; i++) {
    //put lines
    fill("black");
    stroke("0");
    //x axis label
    text("Horsepower", 350, 25);
    //Grid numbers
    fill("grey");
    stroke("0");
    text(stnum + i * 50, i * 50 + 148, 45);
    //draw grid
    stroke(210);
    rect(i * 50 + 155, 50, 0.25, 300);
    //draw horiz lines
    line(620, 68, 150, 68);
    line(620, 115, 150, 115);
    line(620, 165, 150, 165);
    line(620, 215, 150, 215);
    line(620, 265, 150, 265);
    line(620, 315, 150, 315);
  }

  for (var i = 0; i < numRows; i++) {
    //label for cars
    push();
    let angle2 = radians(270);
    translate(20, 250);
    rotate(angle2);
    // Draw the letter to the screen
    fill("black");
    stroke("0");
    text("Top German Car Brands", 0, 0);
    pop();

    //Car Brand labels
    fill("steelblue");
    stroke("0");
    text(table.getString(i, 0), 50, i * 50 + 70);

    //get numbers
    dotValues[i] = table.getString(i, 1);
    //draw graph
    noStroke();
    circle(int(dotValues[i]) + 105, i * 49 + 70, 20);
  }
}
